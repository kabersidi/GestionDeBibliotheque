/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao.com;

import java.util.List;
import metier.com.Livre;

public interface LivreDAO {
    List<Livre> getAllLivres();
    Livre getLivreById(int id);
    void ajouterLivre(Livre livre);
    void modifierLivre(Livre livre);
    void supprimerLivre(int id);

}

