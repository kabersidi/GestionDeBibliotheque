/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao.com;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import bdd.com.BibliothequeDB;
import metier.com.Livre;

public class LivreDAOImpl implements LivreDAO {

    private Connection conn;

    public LivreDAOImpl() {
        this.conn = BibliothequeDB.getInstance();
    }

    @Override
    public List<Livre> getAllLivres() {
        List<Livre> livres = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM livres");
            while (rs.next()) {
                Livre livre = new Livre();
                livre.setId(rs.getInt("id"));
                livre.setTitre(rs.getString("titre"));
                livre.setAuteur(rs.getString("auteur"));
                livre.setAnnee(rs.getInt("annee"));
                livres.add(livre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livres;
    }

    @Override
    public Livre getLivreById(int id) {
        Livre livre = null;
        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM livres WHERE id = ?");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                
                livre = new Livre();
                livre.setId(rs.getInt("id"));
                livre.setTitre(rs.getString("titre"));
                livre.setAuteur(rs.getString("auteur"));
                livre.setAnnee(rs.getInt("annee"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livre;
    }

    @Override
    public void ajouterLivre(Livre livre) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO livres(titre, auteur, annee) VALUES (?, ?, ?)");
            pstmt.setString(1, livre.getTitre());
            pstmt.setString(2, livre.getAuteur());
            pstmt.setInt(3, livre.getAnnee());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void modifierLivre(Livre livre) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("UPDATE livres SET titre = ?, auteur = ?, annee = ? WHERE id = ?");
            pstmt.setString(1, livre.getTitre());
            pstmt.setString(2, livre.getAuteur());
            pstmt.setInt(3, livre.getAnnee());
            pstmt.setInt(4, livre.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void supprimerLivre(int id) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM livres WHERE id = ?");
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    @Override
//    public List<Livre> getLivres() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
    public List<Livre> getLivres(String searchKeyword) {
        List<Livre> livres = new ArrayList<>();
        try {
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM livres WHERE titre LIKE ? OR auteur LIKE ?");
            pstmt.setString(1, "%" + searchKeyword + "%");
            pstmt.setString(2, "%" + searchKeyword + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Livre livre = new Livre();
                livre.setId(rs.getInt("id"));
                livre.setTitre(rs.getString("titre"));
                livre.setAuteur(rs.getString("auteur"));
                livre.setAnnee(rs.getInt("annee"));
                livres.add(livre);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livres;
    }


}

