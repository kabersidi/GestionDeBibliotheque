package bdd.com;

import java.sql.*;

import java.sql.Connection;


public class BibliothequeDB {
    private static Connection instance;
    private Statement statement;

    private BibliothequeDB() {
        try {
            // Chargement du pilote JDBC pour MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

//            com.mysql.cj.jdbc.Driver
            // Connexion à la base de données "bibliotheque"
            instance = DriverManager.getConnection("jdbc:mysql://localhost:3306/bibliotheque", "root", "");
            // Création d'un objet Statement
            statement = instance.createStatement();
            
        } catch (Exception e) {
            e.printStackTrace();
            
            System.out.println(e);
        }
    }
    
    public static Connection getInstance() {
    if (instance == null) {
        new BibliothequeDB();
    }
    return instance;
}
//
//    public static Connection getInstance() {
//        if (instance == null) {
//            instance = BibliothequeDB.instance;
//        }
//        return instance;
//    }

    public ResultSet executeQuery(String sql) {
        try {
            return statement.executeQuery(sql);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void executeUpdate(String sql) {
        try {
            statement.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            statement.close();
            instance.close();
        } catch (Exception e) {
            e.printStackTrace();
             System.out.println("Error: " + e.toString());
        }
    }
}
