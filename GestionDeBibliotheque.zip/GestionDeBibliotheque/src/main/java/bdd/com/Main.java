package bdd.com;

import java.sql.Connection;

public class Main {

    public static void main(String[] args) {
    // Get an instance of the database connection
    try (Connection connection = BibliothequeDB.getInstance()) {
        System.out.println("connection: " + connection);

        // Perform a test query
        String query = "SELECT * FROM livres";
        connection.prepareStatement(query).executeQuery();

        // If there are no errors, the query was successful
        System.out.println("Connection to database successful.");
    } catch (Exception e) {
        e.printStackTrace();
    }
}

}
