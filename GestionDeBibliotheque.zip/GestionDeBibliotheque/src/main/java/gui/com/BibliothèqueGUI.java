/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui.com;
import dao.com.LivreDAO;
import dao.com.LivreDAOImpl;
import metier.com.Livre;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author PC
 */
public class BibliothèqueGUI extends javax.swing.JFrame {

    private JPanel contentPane;
    private JTextField textFieldId;
    private JTextField textFieldTitre;
    private JTextField textFieldAuteur;
    private JTextField textFieldAnnee;
    private JTable table;

    private LivreDAO livreDAO;
    /**
     * Creates new form BibliothèqueGUI
     */
    public BibliothèqueGUI() {
        initComponents();
        
        
            // Créer l'objet LivreDAOImpl
        livreDAO = new LivreDAOImpl();

        // Configurer la fenêtre principale
        setTitle("Gestion de Bibliothèque");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 500);

        // Créer le contenu de la fenêtre
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Créer les étiquettes pour les champs de saisie
        JLabel lblId = new JLabel("ID :");
        lblId.setBounds(20, 20, 46, 14);
        contentPane.add(lblId);

        JLabel lblTitre = new JLabel("Titre :");
        lblTitre.setBounds(20, 45, 46, 14);
        contentPane.add(lblTitre);

        JLabel lblAuteur = new JLabel("Auteur :");
        lblAuteur.setBounds(20, 70, 46, 14);
        contentPane.add(lblAuteur);

        JLabel lblAnnee = new JLabel("Année :");
        lblAnnee.setBounds(20, 95, 46, 14);
        contentPane.add(lblAnnee);

        // Créer les champs de saisie
        textFieldId = new JTextField();
        textFieldId.setBounds(80, 17, 86, 20);
        contentPane.add(textFieldId);
        textFieldId.setColumns(10);

        textFieldTitre = new JTextField();
        textFieldTitre.setBounds(80, 42, 190, 20);
        contentPane.add(textFieldTitre);
        textFieldTitre.setColumns(10);

        textFieldAuteur = new JTextField();
        textFieldAuteur.setBounds(80, 67, 190, 20);
        contentPane.add(textFieldAuteur);
        textFieldAuteur.setColumns(10);

        textFieldAnnee = new JTextField();
        textFieldAnnee.setBounds(80, 92, 86, 20);
        contentPane.add(textFieldAnnee);
        textFieldAnnee.setColumns(10);

        // Créer le bouton "Ajouter"
        JButton btnAjouter = new JButton("Ajouter");
        btnAjouter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ajouterLivre();
            }
        });
        btnAjouter.setBounds(280, 41, 89, 23);
        contentPane.add(btnAjouter);

        // Créer le bouton "Modifier"
        JButton btnModifier = new JButton("Modifier");
        btnModifier.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modifierLivre();
            }
        });
        btnModifier.setBounds(280, 66, 89, 23);
        contentPane.add(btnModifier);

        // Créer le bouton "Supprimer"
        JButton btnSupprimer = new JButton("Supprimer");
        btnSupprimer.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        supprimerLivre();
        }
        });
        btnSupprimer.setBounds(280, 91, 89, 23);
        contentPane.add(btnSupprimer);
            // Créer la table pour afficher les livres
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 130, 664, 320);
        contentPane.add(scrollPane);

        table = new JTable();
        table.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "Titre", "Auteur", "Année"}
        ));
        scrollPane.setViewportView(table);

        // Afficher la liste des livres
        afficherLivres();
    }

    /**
     * Ajouter un livre
     */
    private void ajouterLivre() {
        String titre = textFieldTitre.getText();
        String auteur = textFieldAuteur.getText();
        int annee = Integer.parseInt(textFieldAnnee.getText());

        Livre livre = new Livre(titre, auteur, annee);
        livreDAO.ajouterLivre(livre);

        afficherLivres();
    }

    /**
     * Modifier un livre
     */
    private void modifierLivre() {
        int id = Integer.parseInt(textFieldId.getText());
        String titre = textFieldTitre.getText();
        String auteur = textFieldAuteur.getText();
        int annee = Integer.parseInt(textFieldAnnee.getText());

        Livre livre = new Livre(titre, auteur, id);
        livreDAO.modifierLivre(livre);

        afficherLivres();
    }

    /**
     * Supprimer un livre
     */
    private void supprimerLivre() {
        int id = Integer.parseInt(textFieldId.getText());
        livreDAO.supprimerLivre(id);

        afficherLivres();
    }

    /**
     * Afficher la liste des livres dans la table
     */
    private void afficherLivres() {
        // Récupérer la liste des livres
        List<Livre> listeLivres = livreDAO.getAllLivres();

        // Convertir la liste en un tableau à deux dimensions
        Object[][] tableauLivres = new Object[listeLivres.size()][4];
        for (int i = 0; i < listeLivres.size(); i++) {
            Livre livre = listeLivres.get(i);
            tableauLivres[i][0] = livre.getId();
            tableauLivres[i][1] = livre.getTitre();
            tableauLivres[i][2] = livre.getAuteur();
            tableauLivres[i][3] = livre.getAnnee();
        }

        // Afficher le tableau dans la table
        table.setModel(new DefaultTableModel(
                tableauLivres,
                new String[]{"ID", "Titre", "Auteur", "Année"}
        ));
    }

    public static void main(String[] args) {
        // Créer la fenêtre principale
        BibliothèqueGUI frame = new BibliothèqueGUI();
        frame.setVisible(true);
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//       
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
