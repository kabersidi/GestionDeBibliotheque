/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestiondebibliotheque;

import gui.com.BibliothèqueGUI;

/**
 *                                  
 * @author PC
 */
public class GestionDeBibliotheque {

    public static void main(String[] args) {
//        System.out.println("Kaber project");
         // Créer la fenêtre principale
        BibliothèqueGUI frame = new BibliothèqueGUI();
        frame.setVisible(true);
    }
}
